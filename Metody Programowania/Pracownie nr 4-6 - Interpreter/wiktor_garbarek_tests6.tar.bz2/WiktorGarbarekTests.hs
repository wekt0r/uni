-- Wymagamy, by moduł zawierał tylko bezpieczne funkcje
{-# LANGUAGE Safe #-}
-- Definiujemy moduł zawierający testy.
-- Należy zmienić nazwę modułu na {Imie}{Nazwisko}Tests gdzie za {Imie}
-- i {Nazwisko} należy podstawić odpowiednio swoje imię i nazwisko
-- zaczynające się wielką literą oraz bez znaków diakrytycznych.
module WiktorGarbarekTests(tests) where

-- Importujemy moduł zawierający typy danych potrzebne w zadaniu
import DataTypes

-- Lista testów do zadania
-- Należy uzupełnić jej definicję swoimi testami
tests :: [Test]
tests =
  [ Test "inc"      (SrcString "input x in x + 1") (Eval [42] (Value 43))
  , Test "undefVar" (SrcString "x")                TypeError
  , Test "past_unary" (SrcString "let g = fn(x:int) -> x + 5 in -g") TypeError 
  , Test "past_binary" (SrcString "let g = fn(x:int) -> x + 5 in g mod 7") TypeError
  , Test "nonrecursive_let" (SrcString "let g = fn(x:int) ->  g 1 + 1 in g 2") TypeError
  , Test "lambda_application" (SrcString "(fn (x:int) -> x * 10) 10") (Eval [] (Value 100))
  , Test "more_complicated_lambda" (SrcString "let b = true in (if b then fn (x:int) -> x + 1 else fn(x:int) -> x-3) 3") (Eval [] (Value 4))
  , Test "proper_variable_in_environment" (SrcString "let x = 0 in let f = fn(y:int) -> x + y in let x = 42 in f 1") (Eval [] (Value 1))
  , Test "good_to_parse" (SrcString "1 2") TypeError
  , Test "little_old_ghost" (SrcString "if true then 5 else fn (x : bool) -> if x then true else false") TypeError
  , Test "maybe_unit" (SrcString "(fn(x : unit) -> 1) ()") (Eval [] (Value 1))
  , Test "nested_let" (SrcString "let x = fn(y:int) -> y + 1 in let x = 2 in x 2") TypeError
  , Test "laziness_inside_function" (SrcString "let f = fn(pair: bool*int) -> if fst pair then 1 else 0 div 0 in f (true,10)") (Eval [] (Value 1))
  , Test "same_laziness" (SrcString "let f = fn(pair: bool*int) -> if fst pair then 1 else 0 div 0 in f (false,10)") (Eval [] RuntimeError)
  , Test "overwritten_function_by_let" (SrcFile "overwritten_fun.pp6") TypeError --1 
  , Test "overwritten_fun_eval_check" (SrcFile "overwritten_fun_ok.pp6") (Eval [] (Value 9)) --2
  , Test "good_closure" (SrcFile "closure_ok.pp6") (Eval [] (Value 11)) --3
  , Test "square_of_square" (SrcFile "square_of_square.pp6") (Eval [2] (Value 16)) --4
  , Test "some_list_map" (SrcFile "and_or.pp6") (Eval [] (Value 100)) --5
  , Test "weird_laziness" (SrcString "input x in if let id = fn(a:bool) -> a in id (x = 1) then if id true then 1 else 0 else 0") TypeError

  ]
